const fs = require('fs')
const path = require('path')


function run() {
	const arguments = process.argv.splice(2);
	console.log(arguments[0])
	const filename = arguments[0]
	const bookPath = './' + filename

	const files = fs.readdirSync(bookPath)
	files.forEach(name => {
		const content = fs.readFileSync(bookPath + '/' + name, 'utf8')
		let resolveContent = content
			.replace(/\(未完待续。\)/g, '')
			.replace(/<\/>/g, '')
			.replace(/（很久没求票了，所以我们今天求一下订阅，没订阅的快订阅吧~~~~~~）/g, '')
			.replace(/——————————\(未完待续。\)/g, '')
			.replace(/————————/g, '')
		fs.writeFileSync(bookPath + '/' + name, resolveContent, 'utf8')
	})

}

run()